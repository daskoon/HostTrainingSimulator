# Overview

"What Brings You In Today" is a host/coordinator simulation game inspired by Best Buy electronics retail. Players take on the role of a front desk host who manages customer flow by directing customers to the appropriate sales team members. The core gameplay involves quickly assessing customer needs and coordinating with a 6-7 person sales team using direct communication or walkie-talkie calls, with risks and rewards for different coordination strategies.

The application is built as a single-page React application with a Node.js backend, featuring a real-time customer queue system, sales team status management, and coordination-focused gameplay where players must balance efficiency, energy, team relations, and customer flow through strategic decision-making.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client is built using **React 18** with TypeScript and follows a component-based architecture:

- **State Management**: Zustand with persist middleware for game state management, allowing save/load functionality
- **UI Framework**: Radix UI components with Tailwind CSS for styling, providing accessible and customizable interface elements
- **3D Graphics**: React Three Fiber ecosystem (@react-three/fiber, @react-three/drei, @react-three/postprocessing) for potential 3D elements
- **Data Fetching**: TanStack React Query for server state management and API communication
- **Styling**: Tailwind CSS with custom CSS variables for theming, PostCSS for processing

The game uses a phase-based system (menu → shift → day_summary) with a host-focused interface that displays current customer requests, sales team status, and coordination options. Players can choose between walking over to team members directly, using walkie-talkie calls, or handling situations themselves, each with different efficiency, energy, and relationship impacts.

## Backend Architecture
The server uses **Express.js** with TypeScript in ESM format:

- **API Structure**: RESTful endpoints for game events (`/api/events`) and NPC data (`/api/npc`)
- **Data Storage**: File-based JSON storage for static game content (events, NPCs, dialogue trees), with in-memory storage for user data during development
- **Development Setup**: Vite integration for hot reloading and development middleware
- **Static Assets**: Serves the built React application in production

The backend provides randomized events and NPC data to drive the narrative gameplay loop.

## Database Design
Currently uses **Drizzle ORM** configured for PostgreSQL with:

- **Schema**: Basic user table with username/password fields defined in shared schema
- **Migrations**: Automated migration system through Drizzle Kit
- **Development Storage**: In-memory storage implementation for prototyping, designed to be easily replaced with actual database connection

The database structure is minimal but extensible for future features like user accounts, save games, and analytics.

## Game Data Architecture
The game content is stored in JSON files:

- **Events System**: Structured dialogue trees with branching choices and stat effects
- **NPC System**: Character definitions with mood states, relationship levels, and backstories
- **Stats Tracking**: Customer satisfaction, energy, reputation, and "weirdness level" metrics
- **Save System**: Persistent game state through Zustand's persist middleware

# External Dependencies

## Core Frameworks
- **React 18** with TypeScript for frontend development
- **Express.js** for backend API server
- **Drizzle ORM** for database management with PostgreSQL dialect
- **Vite** for build tooling and development server

## UI and Styling
- **Radix UI** component library for accessible interface elements
- **Tailwind CSS** for utility-first styling approach
- **Lucide React** for consistent iconography
- **Class Variance Authority** for component variant management

## State Management
- **Zustand** for client-side state management with persistence
- **TanStack React Query** for server state and API caching

## 3D Graphics Support
- **React Three Fiber** ecosystem for potential 3D rendering capabilities
- **GLSL shader support** through Vite plugin

## Development Tools
- **TypeScript** for type safety across the entire stack
- **ESBuild** for production bundling
- **PostCSS** with Autoprefixer for CSS processing

## Database Services
- **Neon Database** serverless PostgreSQL (configured but not actively used)
- **Connect-pg-simple** for PostgreSQL session storage

The application is designed with a clear separation between development and production environments, with the database layer abstracted to allow easy switching between storage implementations.