import type { Express } from "express";
import { createServer, type Server } from "http";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";
import { storage } from "./storage";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export async function registerRoutes(app: Express): Promise<Server> {
  const dataDir = path.join(__dirname, "data");

  // Get random event
  app.get("/api/events", async (req, res) => {
    try {
      const eventsData = await fs.readFile(path.join(dataDir, "events.json"), "utf-8");
      const events = JSON.parse(eventsData);
      
      // Get random event
      const randomEvent = events[Math.floor(Math.random() * events.length)];
      res.json(randomEvent);
    } catch (error) {
      console.error("Error loading events:", error);
      res.status(500).json({ error: "Failed to load events" });
    }
  });

  // Get NPC data
  app.get("/api/npc", async (req, res) => {
    try {
      const npcName = req.query.name as string;
      const npcsData = await fs.readFile(path.join(dataDir, "npcs.json"), "utf-8");
      const npcs = JSON.parse(npcsData);
      
      // Find NPC by name
      const npc = npcs.find((n: any) => n.name === npcName || `${n.name} - ${n.type}` === npcName);
      
      if (npc) {
        res.json(npc);
      } else {
        // Return a generic NPC
        res.json({
          id: "generic_001",
          name: npcName.split(" - ")[0] || "Customer",
          type: "customer",
          mood: "neutral",
          avatar: "👤",
          relationshipLevel: 0,
        });
      }
    } catch (error) {
      console.error("Error loading NPC:", error);
      res.status(500).json({ error: "Failed to load NPC data" });
    }
  });

  // Get random customer request
  app.get("/api/customers", async (req, res) => {
    try {
      const customersData = await fs.readFile(path.join(dataDir, "customers.json"), "utf-8");
      const customers = JSON.parse(customersData);
      
      // Get random customer and add timeWaiting
      const randomCustomer = customers[Math.floor(Math.random() * customers.length)];
      randomCustomer.timeWaiting = 0; // New customers start with 0 wait time
      
      res.json(randomCustomer);
    } catch (error) {
      console.error("Error loading customers:", error);
      res.status(500).json({ error: "Failed to load customers" });
    }
  });

  // Save/load player stats
  app.post("/api/stats", async (req, res) => {
    try {
      const { stats } = req.body;
      // In a real app, this would save to a database
      // For now, just acknowledge the save
      res.json({ success: true });
    } catch (error) {
      console.error("Error saving stats:", error);
      res.status(500).json({ error: "Failed to save stats" });
    }
  });

  app.get("/api/stats", async (req, res) => {
    try {
      // In a real app, this would load from a database
      // For now, return default stats
      res.json({
        customerSatisfaction: 75,
        energy: 100,
        reputation: 50,
        weirdness: 0,
      });
    } catch (error) {
      console.error("Error loading stats:", error);
      res.status(500).json({ error: "Failed to load stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
