export type GamePhase = "menu" | "shift" | "day_summary";

export interface PlayerStats {
  efficiency: number; // How well you direct customers (0-100)
  energy: number; // Your stamina for the shift (0-100)
  teamRelations: number; // How much coworkers like working with you (0-100)
  customerFlow: number; // How smooth customer flow is (0-100)
}

export interface SalesTeamMember {
  id: string;
  name: string;
  department: string; // "mobile", "computers", "tvs", "appliances", "gaming", "home-theater", "car-audio"
  availability: "available" | "busy" | "break" | "gone"; // Current status
  expertise: string[]; // What they're good at
  mood: "happy" | "neutral" | "stressed" | "annoyed";
  location: "nearby" | "far" | "unknown";
  relationshipLevel: number; // 0-5, how much they like working with you
}

export interface CustomerRequest {
  id: string;
  customerName: string;
  question: string;
  urgency: "low" | "medium" | "high";
  department: string; // Which department they need
  complexity: "simple" | "medium" | "complex";
  mood: "happy" | "neutral" | "impatient" | "angry" | "frustrated" | "excited" | "confused" | "worried" | "overwhelmed" | "professional" | "hopeful" | "curious" | "disappointed" | "enthusiastic" | "stressed";
  timeWaiting: number; // How long they've been waiting
}

export interface WalkieTalkieAction {
  type: "call_department" | "page_specific" | "general_help";
  target?: string; // Department or specific person
  message: string;
  risk: "low" | "medium" | "high"; // Risk of failure or backlash
}

export interface DirectionChoice {
  type: "direct_speak" | "walkie_call" | "handle_yourself";
  target?: SalesTeamMember;
  action: WalkieTalkieAction | string;
  effect: {
    efficiency?: number;
    energy?: number;
    teamRelations?: number;
    customerFlow?: number;
  };
  risks: string[]; // Potential negative outcomes
}

export interface DayResults {
  customersHelped: number;
  weirdEvents: number;
  notableEvents: string[];
  storeGossip: string;
}

export interface GameSave {
  playerStats: PlayerStats;
  currentDay: number;
  totalCustomersHelped: number;
  achievements: string[];
}