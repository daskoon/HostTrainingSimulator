import { create } from "zustand";
import { persist } from "zustand/middleware";
import { PlayerStats, SalesTeamMember, CustomerRequest, DirectionChoice, DayResults, GamePhase } from "../gameTypes";

interface GameState {
  // Game state
  gamePhase: GamePhase;
  shiftTime: number; // minutes remaining
  isShiftActive: boolean;
  
  // Current customer situation
  currentCustomer: CustomerRequest | null;
  customerQueue: CustomerRequest[];
  
  // Sales team
  salesTeam: SalesTeamMember[];
  
  // Player data
  playerStats: PlayerStats;
  dayResults: DayResults | null;
  
  // Counters
  customersDirectedToday: number;
  successfulHandoffs: number;
  walkieTalkieUses: number;
  
  // Actions
  initializeGame: () => void;
  startShift: () => void;
  endShift: () => void;
  startNewShift: () => void;
  goToMenu: () => void;
  fetchNewCustomer: () => Promise<void>;
  makeDirection: (choice: DirectionChoice) => Promise<void>;
  useWalkieTalkie: (action: string, target?: string) => Promise<void>;
  updateTeamMemberStatus: (memberId: string, status: SalesTeamMember['availability']) => void;
  clearCurrentCustomer: () => void;
  updateStats: (changes: Partial<PlayerStats>) => void;
}

export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      // Initial state
      gamePhase: "menu",
      shiftTime: 480, // 8 hours in minutes
      isShiftActive: false,
      currentCustomer: null,
      customerQueue: [],
      
      salesTeam: getInitialSalesTeam(),
      
      playerStats: {
        efficiency: 75,
        energy: 100,
        teamRelations: 50,
        customerFlow: 75,
      },
      
      dayResults: null,
      customersDirectedToday: 0,
      successfulHandoffs: 0,
      walkieTalkieUses: 0,

      initializeGame: () => {
        console.log("Host game initialized - Welcome to the front desk!");
      },

      startShift: () => {
        set({
          gamePhase: "shift",
          isShiftActive: true,
          shiftTime: 480, // 8 hours
          customersDirectedToday: 0,
          successfulHandoffs: 0,
          walkieTalkieUses: 0,
          dayResults: null,
          currentCustomer: null,
          customerQueue: [],
          salesTeam: getInitialSalesTeam(),
        });
        
        // Start the shift timer - 8 real minutes = 8 hour shift
        const timer = setInterval(() => {
          const state = get();
          if (state.shiftTime > 0 && state.isShiftActive) {
            set({ shiftTime: state.shiftTime - 1 });
            
            // Update team member statuses randomly
            updateTeamStatuses();
            
            // Maybe add a new customer to the queue
            if (Math.random() < 0.3) {
              get().fetchNewCustomer();
            }
          } else {
            clearInterval(timer);
            if (state.isShiftActive) {
              get().endShift();
            }
          }
        }, 1000); // 1 real second = 1 game minute (8 minutes total)
      },

      endShift: () => {
        const state = get();
        const dayResults: DayResults = {
          customersHelped: state.customersDirectedToday,
          weirdEvents: 0, // TODO: implement weird events for host game
          notableEvents: [`Directed ${state.customersDirectedToday} customers`, `Used walkie-talkie ${state.walkieTalkieUses} times`],
          storeGossip: generateHostStoreGossip(state),
        };
        
        set({
          gamePhase: "day_summary",
          isShiftActive: false,
          dayResults,
          currentCustomer: null,
          customerQueue: [],
        });
      },

      startNewShift: () => {
        const state = get();
        set({
          gamePhase: "shift",
          isShiftActive: true,
          shiftTime: 480,
          customersDirectedToday: 0,
          successfulHandoffs: 0,
          walkieTalkieUses: 0,
          dayResults: null,
          currentCustomer: null,
          customerQueue: [],
          salesTeam: getInitialSalesTeam(),
          playerStats: {
            ...state.playerStats,
            energy: Math.min(100, state.playerStats.energy + 20), // Rest between shifts
          },
        });
      },

      goToMenu: () => {
        set({
          gamePhase: "menu",
          isShiftActive: false,
          currentCustomer: null,
          customerQueue: [],
        });
      },

      fetchNewCustomer: async () => {
        try {
          const response = await fetch('/api/customers');
          const customer = await response.json();
          
          const state = get();
          if (!state.currentCustomer) {
            set({ currentCustomer: customer });
          } else {
            set({ customerQueue: [...state.customerQueue, customer] });
          }
        } catch (error) {
          console.error('Failed to fetch customer:', error);
          // Fallback to sample customer
          const sampleCustomer = getSampleCustomer();
          const state = get();
          if (!state.currentCustomer) {
            set({ currentCustomer: sampleCustomer });
          } else {
            set({ customerQueue: [...state.customerQueue, sampleCustomer] });
          }
        }
      },

      makeDirection: async (choice: DirectionChoice) => {
        const state = get();
        
        // Apply stat changes based on choice
        const newStats = {
          efficiency: Math.max(0, Math.min(100, 
            state.playerStats.efficiency + (choice.effect.efficiency || 0)
          )),
          energy: Math.max(0, Math.min(100, 
            state.playerStats.energy + (choice.effect.energy || 0)
          )),
          teamRelations: Math.max(0, Math.min(100, 
            state.playerStats.teamRelations + (choice.effect.teamRelations || 0)
          )),
          customerFlow: Math.max(0, Math.min(100, 
            state.playerStats.customerFlow + (choice.effect.customerFlow || 0)
          )),
        };
        
        // Update counters
        const updates: any = {
          playerStats: newStats,
          customersDirectedToday: state.customersDirectedToday + 1,
        };
        
        // Check if it was a successful handoff
        const success = Math.random() > 0.3; // 70% success rate base
        if (success) {
          updates.successfulHandoffs = state.successfulHandoffs + 1;
        }
        
        // Move to next customer
        const nextCustomer = state.customerQueue[0] || null;
        const remainingQueue = state.customerQueue.slice(1);
        
        updates.currentCustomer = nextCustomer;
        updates.customerQueue = remainingQueue;
        
        set(updates);
      },

      useWalkieTalkie: async (action: string, target?: string) => {
        const state = get();
        set({
          walkieTalkieUses: state.walkieTalkieUses + 1,
          playerStats: {
            ...state.playerStats,
            energy: Math.max(0, state.playerStats.energy - 2), // Using walkie takes small energy
          }
        });
      },

      updateTeamMemberStatus: (memberId: string, status: SalesTeamMember['availability']) => {
        const state = get();
        const updatedTeam = state.salesTeam.map(member => 
          member.id === memberId ? { ...member, availability: status } : member
        );
        set({ salesTeam: updatedTeam });
      },

      clearCurrentCustomer: () => {
        const state = get();
        const nextCustomer = state.customerQueue[0] || null;
        const remainingQueue = state.customerQueue.slice(1);
        
        set({ 
          currentCustomer: nextCustomer,
          customerQueue: remainingQueue,
        });
      },

      updateStats: (changes) => {
        const state = get();
        set({
          playerStats: { ...state.playerStats, ...changes }
        });
      },
    }),
    {
      name: "retail-host-game-save",
      partialize: (state) => ({
        playerStats: state.playerStats,
        // Don't persist temporary game state
      }),
    }
  )
);

// Helper functions for the host game
function getInitialSalesTeam(): SalesTeamMember[] {
  return [
    {
      id: "jake_mobile",
      name: "Jake",
      department: "mobile",
      availability: "available",
      expertise: ["smartphones", "tablets", "phone-plans", "accessories"],
      mood: "happy",
      location: "nearby",
      relationshipLevel: 3,
    },
    {
      id: "sarah_computers",
      name: "Sarah",
      department: "computers",
      availability: "available", 
      expertise: ["laptops", "desktops", "gaming", "software"],
      mood: "neutral",
      location: "far",
      relationshipLevel: 2,
    },
    {
      id: "mike_tvs",
      name: "Mike", 
      department: "tvs",
      availability: "busy",
      expertise: ["televisions", "sound-bars", "streaming", "wall-mounting"],
      mood: "neutral",
      location: "nearby",
      relationshipLevel: 4,
    },
    {
      id: "lisa_appliances",
      name: "Lisa",
      department: "appliances",
      availability: "available",
      expertise: ["refrigerators", "washers", "dryers", "installation"],
      mood: "happy",
      location: "far",
      relationshipLevel: 3,
    },
    {
      id: "alex_gaming",
      name: "Alex",
      department: "gaming",
      availability: "break",
      expertise: ["consoles", "gaming-accessories", "pc-gaming", "vr"],
      mood: "stressed",
      location: "unknown",
      relationshipLevel: 1,
    },
    {
      id: "emma_home_theater",
      name: "Emma",
      department: "home-theater",
      availability: "available",
      expertise: ["speakers", "receivers", "home-audio", "installation"],
      mood: "happy",
      location: "nearby",
      relationshipLevel: 5,
    },
    {
      id: "tyler_car_audio",
      name: "Tyler",
      department: "car-audio",
      availability: "gone",
      expertise: ["car-stereos", "speakers", "installation", "electronics"],
      mood: "neutral",
      location: "unknown",
      relationshipLevel: 2,
    },
  ];
}

function updateTeamStatuses() {
  // This would randomly update team member statuses during the shift
  // For now, this is just a placeholder
}

function generateHostStoreGossip(state: any): string {
  const gossips = [
    "The front desk is running smoothly with you coordinating things.",
    "Sales team appreciates how well you direct customers to them.",
    "Customers are getting helped faster since you started hosting.",
    "The walkie-talkie has been getting a workout today!",
    "Management noticed the improved customer flow.",
  ];
  
  if (state.playerStats.teamRelations > 80) {
    return "The sales team really likes working with you!";
  }
  if (state.playerStats.efficiency > 80) {
    return "You're fantastic at matching customers with the right person!";
  }
  if (state.playerStats.customerFlow < 30) {
    return "Customers have been waiting longer than usual...";
  }
  
  return gossips[Math.floor(Math.random() * gossips.length)];
}

function getSampleCustomer(): CustomerRequest {
  const customers: CustomerRequest[] = [
    {
      id: "cust_001",
      customerName: "Jennifer",
      question: "I need help picking a laptop for college. My budget is around $800.",
      urgency: "medium" as const,
      department: "computers",
      complexity: "medium" as const,
      mood: "neutral" as const,
      timeWaiting: 0,
    },
    {
      id: "cust_002", 
      customerName: "Bob",
      question: "My phone screen is cracked. Can you help me get it fixed?",
      urgency: "high" as const,
      department: "mobile",
      complexity: "simple" as const,
      mood: "frustrated" as const,
      timeWaiting: 2,
    },
    {
      id: "cust_003",
      customerName: "Maria",
      question: "I want to set up a home theater system. Need advice on speakers.",
      urgency: "low" as const,
      department: "home-theater", 
      complexity: "complex" as const,
      mood: "happy" as const,
      timeWaiting: 0,
    },
  ];
  
  return customers[Math.floor(Math.random() * customers.length)];
}