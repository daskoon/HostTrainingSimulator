import { useState, useEffect } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import HostGameUI from "./components/game/HostGameUI";
import { DaySummary } from "./components/game/DaySummary";
import { useGameStore } from "./lib/stores/useGameStore";
import "./index.css";

const queryClient = new QueryClient();

function App() {
  const { gamePhase, initializeGame } = useGameStore();

  useEffect(() => {
    initializeGame();
  }, [initializeGame]);

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gradient-to-b from-blue-100 to-blue-200 text-gray-800">
        {gamePhase === 'shift' && <HostGameUI />}
        {gamePhase === 'day_summary' && <DaySummary />}
        {gamePhase === 'menu' && (
          <div className="flex items-center justify-center min-h-screen">
            <div className="text-center p-8 bg-white rounded-lg shadow-lg">
              <h1 className="text-4xl font-bold mb-4 text-blue-600">
                What Brings You In Today?
              </h1>
              <p className="text-lg mb-6 text-gray-600">
                Host customers and coordinate with your sales team!
              </p>
              <button
                onClick={() => useGameStore.getState().startShift()}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Start Your Shift
              </button>
            </div>
          </div>
        )}
      </div>
    </QueryClientProvider>
  );
}

export default App;
