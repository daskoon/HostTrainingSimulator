import { NPC } from "../../lib/gameTypes";

interface NPCPortraitProps {
  npc: NPC;
}

export function NPCPortrait({ npc }: NPCPortraitProps) {
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'customer': return '🛍️';
      case 'coworker': return '👥';
      case 'manager': return '👔';
      case 'vendor': return '📦';
      default: return '👤';
    }
  };

  const getMoodColor = (mood: string) => {
    switch (mood) {
      case 'happy': return 'border-green-400 bg-green-50';
      case 'neutral': return 'border-gray-400 bg-gray-50';
      case 'frustrated': return 'border-yellow-400 bg-yellow-50';
      case 'angry': return 'border-red-400 bg-red-50';
      case 'confused': return 'border-purple-400 bg-purple-50';
      default: return 'border-gray-400 bg-gray-50';
    }
  };

  return (
    <div className={`p-4 rounded-lg border-2 shadow-lg bg-white ${getMoodColor(npc.mood)}`}>
      <div className="text-center">
        {/* Avatar */}
        <div className="text-6xl mb-2">
          {npc.avatar || getTypeIcon(npc.type)}
        </div>
        
        {/* Name and title */}
        <div className="font-bold text-lg text-gray-800">{npc.name}</div>
        <div className="text-sm text-gray-600 capitalize">{npc.type}</div>
        
        {/* Relationship indicator */}
        {npc.relationshipLevel !== undefined && (
          <div className="mt-2">
            <div className="text-xs text-gray-500 mb-1">Relationship</div>
            <div className="flex justify-center">
              {[...Array(5)].map((_, i) => (
                <span
                  key={i}
                  className={`text-sm ${
                    i < npc.relationshipLevel! ? 'text-yellow-400' : 'text-gray-300'
                  }`}
                >
                  ⭐
                </span>
              ))}
            </div>
          </div>
        )}
        
        {/* Mood indicator */}
        <div className="mt-2 text-xs text-gray-600 capitalize">
          Mood: {npc.mood}
        </div>
      </div>
    </div>
  );
}