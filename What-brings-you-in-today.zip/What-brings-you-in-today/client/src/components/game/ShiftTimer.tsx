interface ShiftTimerProps {
  timeRemaining: number; // in minutes
}

export function ShiftTimer({ timeRemaining }: ShiftTimerProps) {
  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}:${mins.toString().padStart(2, '0')}`;
  };

  const getTimeColor = (minutes: number) => {
    if (minutes > 120) return 'text-green-600'; // More than 2 hours
    if (minutes > 60) return 'text-yellow-600';  // More than 1 hour
    if (minutes > 30) return 'text-orange-600';  // More than 30 minutes
    return 'text-red-600'; // Less than 30 minutes
  };

  const getProgressPercentage = (minutes: number) => {
    return (minutes / 480) * 100; // 480 minutes = 8 hours
  };

  return (
    <div className="bg-white rounded-lg p-4 shadow-sm border min-w-[200px]">
      <div className="text-center">
        <div className="text-sm font-medium text-gray-600 mb-1">Shift Time Remaining</div>
        <div className={`text-2xl font-bold ${getTimeColor(timeRemaining)}`}>
          {formatTime(timeRemaining)}
        </div>
        
        {/* Progress bar */}
        <div className="mt-3 w-full bg-gray-200 rounded-full h-2">
          <div
            className={`h-2 rounded-full transition-all duration-300 ${
              timeRemaining > 120 ? 'bg-green-500' :
              timeRemaining > 60 ? 'bg-yellow-500' :
              timeRemaining > 30 ? 'bg-orange-500' : 'bg-red-500'
            }`}
            style={{ width: `${Math.max(0, getProgressPercentage(timeRemaining))}%` }}
          />
        </div>
        
        {/* Status */}
        <div className="mt-2 text-xs text-gray-500">
          {timeRemaining > 240 ? 'Just started' :
           timeRemaining > 120 ? 'Mid-shift' :
           timeRemaining > 60 ? 'Getting late' :
           timeRemaining > 30 ? 'Almost done' :
           timeRemaining > 0 ? 'Final stretch!' : 'Shift ended'}
        </div>
      </div>
    </div>
  );
}