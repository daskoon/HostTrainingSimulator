import { useEffect, useState } from "react";
import { DialogueBox } from "./DialogueBox";
import { StatBar } from "./StatBar";
import { ShiftTimer } from "./ShiftTimer";
import { NPCPortrait } from "./NPCPortrait";
import { useGameStore } from "../../lib/stores/useGameStore";

export function GameUI() {
  const { 
    currentEvent, 
    playerStats, 
    currentNPC,
    shiftTime,
    isShiftActive,
    fetchNewEvent,
    endShift
  } = useGameStore();

  const [showNewCustomer, setShowNewCustomer] = useState(false);

  useEffect(() => {
    if (!currentEvent && isShiftActive) {
      const timer = setTimeout(() => {
        fetchNewEvent();
        setShowNewCustomer(true);
        setTimeout(() => setShowNewCustomer(false), 2000);
      }, Math.random() * 3000 + 2000); // Random delay between 2-5 seconds
      
      return () => clearTimeout(timer);
    }
  }, [currentEvent, isShiftActive, fetchNewEvent]);

  useEffect(() => {
    if (shiftTime <= 0 && isShiftActive) {
      endShift();
    }
  }, [shiftTime, isShiftActive, endShift]);

  return (
    <div className="flex flex-col h-screen bg-gradient-to-b from-orange-100 to-yellow-100">
      {/* Header with stats and timer */}
      <div className="bg-white shadow-md p-4 border-b-2 border-orange-200">
        <div className="flex justify-between items-center max-w-6xl mx-auto">
          <div className="flex-1">
            <StatBar stats={playerStats} />
          </div>
          <div className="ml-4">
            <ShiftTimer timeRemaining={shiftTime} />
          </div>
        </div>
      </div>

      {/* Main game area */}
      <div className="flex-1 flex">
        {/* Store environment (visual) */}
        <div className="flex-1 bg-gradient-to-r from-blue-200 to-purple-200 relative overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-gray-600">
              <div className="text-6xl mb-4">🏪</div>
              <h2 className="text-2xl font-bold mb-2">TechMart Electronics</h2>
              <p className="text-lg">Customer Service Desk</p>
            </div>
          </div>
          
          {/* New customer notification */}
          {showNewCustomer && (
            <div className="absolute top-4 left-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg animate-bounce">
              New customer approaching!
            </div>
          )}
          
          {/* Current NPC display */}
          {currentNPC && (
            <div className="absolute bottom-20 right-8">
              <NPCPortrait npc={currentNPC} />
            </div>
          )}
        </div>

        {/* Dialogue area */}
        <div className="w-96 bg-white border-l-2 border-orange-200">
          {currentEvent ? (
            <DialogueBox event={currentEvent} />
          ) : (
            <div className="p-6 text-center text-gray-500">
              <div className="text-4xl mb-4">⏰</div>
              <p>Waiting for the next customer...</p>
              <p className="text-sm mt-2">Stay alert!</p>
            </div>
          )}
        </div>
      </div>

      {/* Footer with controls */}
      <div className="bg-white border-t-2 border-orange-200 p-4">
        <div className="max-w-6xl mx-auto text-center text-gray-600">
          <p className="text-sm">
            💡 Tip: Choose your responses carefully - they affect your stats and reputation!
          </p>
        </div>
      </div>
    </div>
  );
}