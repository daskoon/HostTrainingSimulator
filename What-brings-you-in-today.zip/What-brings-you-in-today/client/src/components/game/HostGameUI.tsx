import React from "react";
import { useGameStore } from "../../lib/stores/useGameStore";
import { SalesTeamMember, CustomerRequest } from "../../lib/gameTypes";

export default function HostGameUI() {
  const {
    currentCustomer,
    customerQueue,
    salesTeam,
    playerStats,
    shiftTime,
    customersDirectedToday,
    successfulHandoffs,
    walkieTalkieUses,
    makeDirection,
    useWalkieTalkie,
    clearCurrentCustomer,
  } = useGameStore();

  if (!currentCustomer) {
    return (
      <div className="flex flex-col items-center justify-center h-96 space-y-4">
        <div className="text-lg text-gray-600">
          No customers at the moment... 
        </div>
        <div className="text-sm text-gray-500">
          Queue: {customerQueue.length} waiting
        </div>
      </div>
    );
  }

  const getAvailableTeamMembers = (department: string) => {
    return salesTeam.filter(member => 
      (member.department === department || department === "any") &&
      member.availability === "available"
    );
  };

  const handleDirectSpeak = (member: SalesTeamMember) => {
    const choice = {
      type: "direct_speak" as const,
      target: member,
      action: `Walk over to ${member.name} and bring them the customer`,
      effect: {
        efficiency: member.location === "nearby" ? 5 : -2,
        energy: member.location === "nearby" ? -2 : -5,
        teamRelations: member.relationshipLevel > 3 ? 2 : -1,
        customerFlow: 3,
      },
      risks: member.location === "far" ? ["Takes time to walk over", "Customer waits longer"] : [],
    };
    
    makeDirection(choice);
  };

  const handleWalkieTalkie = (department: string, specific?: string) => {
    const choice = {
      type: "walkie_call" as const,
      action: specific 
        ? `"${specific}, customer needs help with ${currentCustomer.question}"`
        : `"${department} team, customer needs assistance"`,
      effect: {
        efficiency: 3,
        energy: -1,
        teamRelations: 1,
        customerFlow: 2,
      },
      risks: ["Team member might not respond", "Might be on another call"],
    };
    
    makeDirection(choice);
    useWalkieTalkie(choice.action, specific || department);
  };

  const handleSelfService = () => {
    const choice = {
      type: "handle_yourself" as const,
      action: "Try to help the customer yourself",
      effect: {
        efficiency: -5,
        energy: -8,
        customerFlow: -3,
      },
      risks: ["Might not have the expertise", "Takes much longer", "Other customers wait"],
    };
    
    makeDirection(choice);
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "high": return "text-red-600 bg-red-100";
      case "medium": return "text-yellow-600 bg-yellow-100";
      case "low": return "text-green-600 bg-green-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  const getMoodEmoji = (mood: string) => {
    switch (mood) {
      case "happy": return "😊";
      case "excited": return "😃";
      case "neutral": return "😐";
      case "confused": return "😕";
      case "frustrated": return "😤";
      case "angry": return "😠";
      case "worried": return "😟";
      case "impatient": return "😒";
      case "overwhelmed": return "😵";
      case "professional": return "🧑‍💼";
      case "hopeful": return "🤞";
      case "curious": return "🤔";
      case "disappointed": return "😞";
      case "enthusiastic": return "🤩";
      case "stressed": return "😰";
      default: return "😐";
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Bar */}
      <div className="bg-white rounded-lg shadow-md p-4">
        <div className="grid grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-sm text-gray-600">Efficiency</div>
            <div className="text-2xl font-bold text-blue-600">{playerStats.efficiency}%</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">Energy</div>
            <div className="text-2xl font-bold text-green-600">{playerStats.energy}%</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">Team Relations</div>
            <div className="text-2xl font-bold text-purple-600">{playerStats.teamRelations}%</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">Customer Flow</div>
            <div className="text-2xl font-bold text-orange-600">{playerStats.customerFlow}%</div>
          </div>
        </div>
        
        <div className="mt-4 text-center text-sm text-gray-600">
          Time: {Math.floor(shiftTime / 60)}:{(shiftTime % 60).toString().padStart(2, '0')} | 
          Directed: {customersDirectedToday} | 
          Successful: {successfulHandoffs} | 
          Walkie Uses: {walkieTalkieUses}
          {customerQueue.length > 0 && ` | Queue: ${customerQueue.length}`}
        </div>
      </div>

      {/* Current Customer */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
              {getMoodEmoji(currentCustomer.mood)} {currentCustomer.customerName}
            </h3>
            <div className="flex items-center gap-2 mt-1">
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor(currentCustomer.urgency)}`}>
                {currentCustomer.urgency.toUpperCase()}
              </span>
              <span className="text-sm text-gray-600">
                Department: {currentCustomer.department}
              </span>
              <span className="text-sm text-gray-600">
                Complexity: {currentCustomer.complexity}
              </span>
            </div>
          </div>
          {currentCustomer.timeWaiting > 0 && (
            <div className="text-right">
              <div className="text-sm text-red-600 font-medium">
                Waiting: {currentCustomer.timeWaiting}m
              </div>
            </div>
          )}
        </div>

        <div className="bg-gray-50 p-4 rounded-lg mb-4">
          <p className="text-gray-800">"{currentCustomer.question}"</p>
        </div>

        {/* Action Options */}
        <div className="space-y-4">
          <h4 className="font-semibold text-gray-800">How do you want to handle this?</h4>
          
          {/* Direct Speak Options */}
          <div>
            <h5 className="text-sm font-medium text-gray-700 mb-2">Walk over and speak directly:</h5>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {getAvailableTeamMembers(currentCustomer.department).map(member => (
                <button
                  key={member.id}
                  onClick={() => handleDirectSpeak(member)}
                  className="p-3 border border-gray-300 rounded-lg hover:bg-blue-50 hover:border-blue-300 text-left transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{member.name}</span>
                    <span className={`text-xs px-2 py-1 rounded ${
                      member.location === "nearby" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                    }`}>
                      {member.location}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600">
                    {member.department} • Mood: {member.mood}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Walkie Talkie Options */}
          <div>
            <h5 className="text-sm font-medium text-gray-700 mb-2">Use walkie-talkie 📻:</h5>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
              <button
                onClick={() => handleWalkieTalkie(currentCustomer.department)}
                className="p-3 border border-gray-300 rounded-lg hover:bg-green-50 hover:border-green-300 transition-colors"
              >
                <div className="font-medium">Call {currentCustomer.department}</div>
                <div className="text-sm text-gray-600">General department call</div>
              </button>
              
              {getAvailableTeamMembers(currentCustomer.department).slice(0, 2).map(member => (
                <button
                  key={`walkie_${member.id}`}
                  onClick={() => handleWalkieTalkie(currentCustomer.department, member.name)}
                  className="p-3 border border-gray-300 rounded-lg hover:bg-green-50 hover:border-green-300 transition-colors"
                >
                  <div className="font-medium">Page {member.name}</div>
                  <div className="text-sm text-gray-600">Direct call</div>
                </button>
              ))}
            </div>
          </div>

          {/* Self Service Option */}
          <div>
            <button
              onClick={handleSelfService}
              className="w-full p-3 border border-red-300 rounded-lg hover:bg-red-50 hover:border-red-400 transition-colors text-left"
            >
              <div className="font-medium text-red-700">Handle it yourself</div>
              <div className="text-sm text-red-600">⚠️ Risky - You might not have the expertise</div>
            </button>
          </div>

          {/* Skip/Delay Option */}
          <div>
            <button
              onClick={clearCurrentCustomer}
              className="w-full p-3 border border-gray-400 rounded-lg hover:bg-gray-50 hover:border-gray-500 transition-colors text-left"
            >
              <div className="font-medium text-gray-700">Ask them to wait / Next customer</div>
              <div className="text-sm text-gray-600">Move to next customer (current one goes to back of queue)</div>
            </button>
          </div>
        </div>
      </div>

      {/* Team Status */}
      <div className="bg-white rounded-lg shadow-md p-4">
        <h4 className="font-semibold text-gray-800 mb-3">Sales Team Status</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {salesTeam.map(member => (
            <div key={member.id} className="p-3 border rounded-lg">
              <div className="flex items-center justify-between mb-1">
                <span className="font-medium">{member.name}</span>
                <span className={`text-xs px-2 py-1 rounded ${
                  member.availability === "available" ? "bg-green-100 text-green-700" :
                  member.availability === "busy" ? "bg-red-100 text-red-700" :
                  member.availability === "break" ? "bg-yellow-100 text-yellow-700" :
                  "bg-gray-100 text-gray-700"
                }`}>
                  {member.availability}
                </span>
              </div>
              <div className="text-sm text-gray-600">
                {member.department} • {member.location}
              </div>
              <div className="text-xs text-gray-500">
                Relationship: {member.relationshipLevel}/5
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}