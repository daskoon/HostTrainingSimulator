import { PlayerStats } from "../../lib/gameTypes";

interface StatBarProps {
  stats: PlayerStats;
}

export function StatBar({ stats }: StatBarProps) {
  const getStatColor = (value: number, max: number = 100) => {
    const percentage = (value / max) * 100;
    if (percentage >= 70) return 'bg-green-500';
    if (percentage >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getStatIcon = (statName: string) => {
    switch (statName) {
      case 'customerSatisfaction': return '😊';
      case 'energy': return '⚡';
      case 'reputation': return '⭐';
      case 'weirdness': return '🔮';
      default: return '📊';
    }
  };

  const formatStatName = (statName: string) => {
    switch (statName) {
      case 'customerSatisfaction': return 'Customer Satisfaction';
      case 'energy': return 'Energy';
      case 'reputation': return 'Reputation';
      case 'weirdness': return 'Weirdness Level';
      default: return statName;
    }
  };

  return (
    <div className="grid grid-cols-4 gap-4">
      {Object.entries(stats).map(([key, value]) => {
        const max = key === 'weirdness' ? 50 : 100;
        const percentage = (value / max) * 100;
        
        return (
          <div key={key} className="bg-white rounded-lg p-3 shadow-sm border">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <span className="text-lg">{getStatIcon(key)}</span>
                <span className="text-sm font-medium text-gray-700">
                  {formatStatName(key)}
                </span>
              </div>
              <span className="text-sm font-bold text-gray-800">
                {value}/{max}
              </span>
            </div>
            
            {/* Progress bar */}
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all duration-300 ${getStatColor(value, max)}`}
                style={{ width: `${Math.min(percentage, 100)}%` }}
              />
            </div>
            
            {/* Status indicator */}
            <div className="mt-1 text-xs text-gray-500 text-center">
              {percentage >= 80 ? 'Excellent' :
               percentage >= 60 ? 'Good' :
               percentage >= 40 ? 'Fair' :
               percentage >= 20 ? 'Poor' : 'Critical'}
            </div>
          </div>
        );
      })}
    </div>
  );
}