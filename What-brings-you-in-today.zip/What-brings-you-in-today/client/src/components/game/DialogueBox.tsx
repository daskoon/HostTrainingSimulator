import { useState } from "react";
import { useGameStore } from "../../lib/stores/useGameStore";
import { DialogueEvent } from "../../lib/gameTypes";

interface DialogueBoxProps {
  event: DialogueEvent;
}

export function DialogueBox({ event }: DialogueBoxProps) {
  const { makeChoice, clearCurrentEvent } = useGameStore();
  const [currentDialogueIndex, setCurrentDialogueIndex] = useState(0);
  const [isChoosing, setIsChoosing] = useState(false);

  const currentDialogue = event.dialogue[currentDialogueIndex];

  const handleChoice = async (choice: any) => {
    setIsChoosing(true);
    
    try {
      await makeChoice(choice);
      
      // Check if there's a next dialogue
      if (choice.next) {
        const nextIndex = event.dialogue.findIndex((d: any) => d.id === choice.next);
        if (nextIndex !== -1) {
          setCurrentDialogueIndex(nextIndex);
          setIsChoosing(false);
          return;
        }
      }
      
      // End the conversation
      setTimeout(() => {
        clearCurrentEvent();
        setIsChoosing(false);
      }, 1500);
      
    } catch (error) {
      console.error('Error making choice:', error);
      setIsChoosing(false);
    }
  };

  if (!currentDialogue) {
    return (
      <div className="p-6 text-center text-gray-500">
        <p>Conversation ended</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-white">
      {/* NPC Info Header */}
      <div className="bg-blue-600 text-white p-4 border-b">
        <h3 className="font-bold text-lg">{event.npc}</h3>
        <div className="text-sm opacity-90">Customer Service Interaction</div>
      </div>

      {/* Dialogue Content */}
      <div className="flex-1 p-6 overflow-y-auto">
        <div className="mb-6">
          <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-r-lg">
            <p className="text-gray-800 leading-relaxed">{currentDialogue.text}</p>
          </div>
        </div>

        {/* Response Choices */}
        {!isChoosing && (
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-700 mb-3">Your Response:</h4>
            {currentDialogue.choices.map((choice, index) => (
              <button
                key={index}
                onClick={() => handleChoice(choice)}
                className="w-full text-left p-4 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <div className="text-gray-800">{choice.text}</div>
                
                {/* Show stat effects preview */}
                {choice.effect && (
                  <div className="mt-2 flex flex-wrap gap-2 text-xs">
                    {Object.entries(choice.effect).map(([stat, value]) => (
                      value !== 0 && (
                        <span
                          key={stat}
                          className={`px-2 py-1 rounded ${
                            (value as number) > 0
                              ? 'bg-green-100 text-green-700'
                              : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {stat}: {value as number > 0 ? '+' : ''}{value}
                        </span>
                      )
                    ))}
                  </div>
                )}
              </button>
            ))}
          </div>
        )}

        {/* Processing state */}
        {isChoosing && (
          <div className="text-center py-8">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <p className="mt-4 text-gray-600">Processing your response...</p>
          </div>
        )}
      </div>

      {/* Tips footer */}
      <div className="bg-gray-50 p-3 border-t">
        <p className="text-xs text-gray-500 text-center">
          💡 Different responses affect your Customer Satisfaction, Energy, Reputation, and Weirdness Level
        </p>
      </div>
    </div>
  );
}