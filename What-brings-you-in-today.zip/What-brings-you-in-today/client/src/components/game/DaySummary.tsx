import { useGameStore } from "../../lib/stores/useGameStore";

export function DaySummary() {
  const { dayResults, playerStats, startNewShift, goToMenu } = useGameStore();

  const getGrade = (score: number) => {
    if (score >= 80) return { grade: 'A', color: 'text-green-600', bg: 'bg-green-100' };
    if (score >= 60) return { grade: 'B', color: 'text-blue-600', bg: 'bg-blue-100' };
    if (score >= 40) return { grade: 'C', color: 'text-yellow-600', bg: 'bg-yellow-100' };
    return { grade: 'D', color: 'text-red-600', bg: 'bg-red-100' };
  };

  const overallScore = Math.round(
    (playerStats.customerSatisfaction + playerStats.energy + playerStats.reputation) / 3
  );
  const gradeInfo = getGrade(overallScore);

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-100 to-pink-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl p-8 max-w-2xl w-full">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">Shift Complete!</h1>
          <div className={`inline-flex items-center px-6 py-3 rounded-full ${gradeInfo.bg}`}>
            <span className={`text-3xl font-bold ${gradeInfo.color}`}>
              Overall Grade: {gradeInfo.grade}
            </span>
          </div>
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-2 gap-6 mb-8">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-700 mb-3">Final Stats</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>😊 Customer Satisfaction:</span>
                <span className="font-medium">{playerStats.customerSatisfaction}/100</span>
              </div>
              <div className="flex justify-between">
                <span>⚡ Energy:</span>
                <span className="font-medium">{playerStats.energy}/100</span>
              </div>
              <div className="flex justify-between">
                <span>⭐ Reputation:</span>
                <span className="font-medium">{playerStats.reputation}/100</span>
              </div>
              <div className="flex justify-between">
                <span>🔮 Weirdness Level:</span>
                <span className="font-medium">{playerStats.weirdness}/50</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-700 mb-3">Shift Activity</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Customers Helped:</span>
                <span className="font-medium">{dayResults?.customersHelped || 0}</span>
              </div>
              <div className="flex justify-between">
                <span>Weird Events:</span>
                <span className="font-medium">{dayResults?.weirdEvents || 0}</span>
              </div>
              <div className="flex justify-between">
                <span>Shift Duration:</span>
                <span className="font-medium">8 hours</span>
              </div>
            </div>
          </div>
        </div>

        {/* Notable Events */}
        {dayResults?.notableEvents && dayResults.notableEvents.length > 0 && (
          <div className="mb-8">
            <h3 className="font-semibold text-gray-700 mb-3">Notable Events</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                {dayResults.notableEvents.map((event: string, index: number) => (
                  <li key={index}>{event}</li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* Store Gossip */}
        {dayResults?.storeGossip && (
          <div className="mb-8">
            <h3 className="font-semibold text-gray-700 mb-3">💬 Store Gossip</h3>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <p className="text-sm text-gray-700 italic">"{dayResults.storeGossip}"</p>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex space-x-4">
          <button
            onClick={startNewShift}
            className="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
          >
            Work Another Shift
          </button>
          <button
            onClick={goToMenu}
            className="flex-1 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-medium"
          >
            Main Menu
          </button>
        </div>
      </div>
    </div>
  );
}